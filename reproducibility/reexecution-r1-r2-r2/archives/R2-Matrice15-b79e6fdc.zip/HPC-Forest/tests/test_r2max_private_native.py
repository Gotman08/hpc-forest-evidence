"""Neutral Python negatives only: no compiler, candidate, CLI, worker connection or model."""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import subprocess
import time
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from hpc_forest import codex_process, contracts
from hpc_forest import native_r2max as native
from hpc_forest.core import InfrastructureError, Mission, Outcome, atomic_json, file_digest
from hpc_forest.observations import _logs
from hpc_forest.primes_contract import (
    COMPILER_FLAGS,
    PREPARATION_MANIFEST_SHA256,
    REFERENCE_SHA256,
    expected_mapping,
    specification,
    verify_preparation,
    verify_resolved_expected,
)
from hpc_forest.primes_lane_contract import (
    EVIDENCE_FIELDS,
    LANE_SCHEMA,
    PLAN_CONTRACT,
    PROJECTION_SCHEMA,
    RECON_SHA,
    SCIENCE_SHA,
)
from hpc_forest.private_feedback import diagnostic_logs, public_diagnostic, public_outcome
from hpc_forest.r2max_first_start import first_start_receipt, inspect_call

MODEL = "gpt-6-astra"
SESSION = native.CELLS[MODEL]


@pytest.fixture(autouse=True)
def no_real_processes(monkeypatch):
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: pytest.fail("Real process forbidden in neutral tests"))
    monkeypatch.setattr(subprocess, "Popen", lambda *a, **k: pytest.fail("Real process forbidden in neutral tests"))


@pytest.fixture
def sealed():
    return Path(os.environ["R2MAX_CERTIFIED_PACKAGE"]).resolve(strict=True)


@pytest.fixture
def authorization(tmp_path, sealed):
    def save(name, value):
        path = tmp_path / name
        atomic_json(path, value)
        return {"path": str(path.resolve()), "sha256": file_digest(path)}
    source = tmp_path / "source.zip"
    source.write_bytes(b"NEUTRAL_NOT_A_SOURCE_BUNDLE")
    refs = {"source_zip": {"path": str(source), "sha256": file_digest(source)},
            "preparation_manifest": {"path": str(sealed / "prototype-manifest.json"), "sha256": PREPARATION_MANIFEST_SHA256}}
    review = {"schema": "hpc-forest-primes-certified-max-independent-final-review-v1",
              "blocking_findings": [], "package": {"manifest_sha256": PREPARATION_MANIFEST_SHA256}}
    refs["preparation_review"] = save("review.json", review)
    plan = {"schema": "hpc-forest-primes-native-max-plan-v2", "scope_id": native.SCOPE,
            "source_zip_sha256": refs["source_zip"]["sha256"],
            "preparation_manifest_sha256": PREPARATION_MANIFEST_SHA256,
            "cells": native.CELLS, "efforts": ["max"],
            "luna_source_zip_sha256": native.LUNA_SOURCE, "automatic_extension": False,
            "worker_lane_contract": PLAN_CONTRACT,
            "maximum_native_workers_total": 4, "maximum_cells_per_authorization": 1}
    refs["plan"] = save("plan.json", plan)
    binding = native.cell_binding({"model": MODEL, "effort": "max", "session_id": SESSION,
        "job_id": "999999", "remote_root": "/NEUTRAL/" + native.SCOPE + "-" + SESSION,
        "artifacts": refs})
    policy = {"schema": codex_process.TASK_CLI_POLICY_SCHEMA, **binding,
        "cli_executable_sha256": "1" * 64,
        "skill_candidate_directories": ["C:/NEUTRAL/skill-one"],
        "filesystem_metadata_sha256": "4" * 64,
        "is_actual_CLI_discovery_receipt": False, "instruction_or_SKILL_body_read": False,
        "cli_feature_overrides": dict(codex_process.TASK_CLI_FEATURES),
        "code_mode_host_executable_sha256": codex_process.CODE_MODE_HOST_SHA256}
    policy_ref = save("cli-policy-" + SESSION + ".json", policy)
    assert codex_process.load_task_cli_policy(Path(policy_ref["path"]), policy_ref["sha256"], binding, "1" * 64) == policy
    for key in ("luna_first_start", "luna_closure"):
        refs[key] = save(key + ".json", {"verified": False, "neutral_fixture_only": True})
    for key, schema in native.SCHEMAS.items():
        item = {"schema": schema, "scope_id": native.SCOPE, "verified": True,
                "source_zip_sha256": refs["source_zip"]["sha256"], "plan_sha256": refs["plan"]["sha256"],
                "preparation_manifest_sha256": PREPARATION_MANIFEST_SHA256}
        if key == "allocated_contract_qualification":
            item.update(compiler_flags=COMPILER_FLAGS, reference_source_sha256=REFERENCE_SHA256,
                        reference_outputs_all_certified_bytes=True, unique_certified_cases=12,
                        native_model_calls=0, allocation={"architecture": "aarch64", "job_id": "999998", "nodes": 1, "tasks": 1, "cpus_per_task": 4, "memory_mib": 16384, "gpus": 0})
        elif key == "transport_admission":
            item.update(model=MODEL, effort="max", session_id=SESSION, job_id="999999",
                        native_model_calls=0, normal_first_call_proved=False, cli_tools_disabled=True)
        elif key == "cli_identity":
            item.update(version="neutral-not-executed", executable_path=str(tmp_path / "neutral-cli"),
                        executable_sha256="1" * 64, source_execution_allowed=False,
                        task_cli_policy_sha256=policy_ref["sha256"])
        elif key == "worker_lane_admission":
            item.update(active_native_workers_before_start=1, maximum_native_workers=4)
        elif key == "integration_review":
            item.update(neutral_tests_passed=True, blocking_findings=[])
        elif key == "extension_admission":
            item.update(model=MODEL, effort="max", session_id=SESSION, job_id="999999",
                        luna_first_start_sha256=refs["luna_first_start"]["sha256"],
                        luna_closure_sha256=refs["luna_closure"]["sha256"], human_max_only=True,
                        one_cell_only=True, automatic_extension=False, all_prior_calls_reconciled=True, maximum_native_workers=4)
        elif key == "session_freshness":
            item.update(model=MODEL, effort="max", session_id=SESSION, job_id="999999",
                        observed_at="NEUTRAL_NOT_A_LIVE_OBSERVATION", verified_no_prior_claims=True,
                        new_cache=True, new_registry=True, native_calls_started_at_admission=0)
        refs[key] = save(key + ".json", item)
    value = {"schema": "hpc-forest-primes-r2max-authorization-v2", "scope_id": native.SCOPE,
             "model": MODEL, "effort": "max", "session_id": SESSION,
             "verified": True, "expires_at": time.time() + 3600,
             "user_messages": ["NEUTRAL TEST DATA ONLY"], "old_candidates_imported": False,
             "operator_algorithm_advice": False, "native_calls_started_at_authorization": 0,
             "job_id": "999999", "remote_root": "/NEUTRAL/" + native.SCOPE + "-" + SESSION,
             "artifacts": refs}
    # Inert, hash-bound projection data only. No real Windows census or process.
    binding, observed = native.cell_binding(value), time.time()
    evidence = {key: "2" * 64 for key in EVIDENCE_FIELDS}
    evidence.update(scientific_reception=SCIENCE_SHA, reconciliation=RECON_SHA)
    projection = {**binding, "schema": PROJECTION_SCHEMA, "verified": True,
        "source_only_state": "received_absent", "source_only_preserved": False,
        "source_only_active_workers": 0, "other_native_workers_count": 1,
        "active_native_workers_before_start": 1, "maximum_native_workers_total": 4,
        "observed_at": observed, "observation_origin": "parent-private-Windows-census",
        "windows_census_observed_by_arm": False, "full_census_exported": False,
        "foreign_configuration_or_credentials_exported": False, "evidence_sha256": evidence}
    lane = {**binding, "schema": LANE_SCHEMA, "verified": True,
        "maximum_native_workers_total": 4, "active_native_workers_before_start": 1,
        "full_census_locally_verified": True, "source_only_preserved": False,
        "new_cache_registry_root": True, "native_calls_started": 0, "observed_at": observed,
        "private_full_census_sha256": evidence["private_full_census"],
        "minimal_owned_observations": save("NEUTRAL-projection.json", projection),
        "source_only_state": "received_absent", "source_only_active_workers": 0}
    wrapper = native.read_json(Path(refs["worker_lane_admission"]["path"]))
    wrapper.update(lane_v2=lane, observed_at=observed)
    refs["worker_lane_admission"] = save("NEUTRAL-worker-lane-v2.json", wrapper)
    path = tmp_path / "authorization.json"
    atomic_json(path, value)
    return path, value, save


def check(path):
    # Metadata unit tests stub only the independently tested real-reception gate.
    # This neutral non-ZIP fixture is never a deployable/native admission.
    with patch.object(native, "verify_reception", lambda *args: None), patch.object(native, "verify_luna_release", lambda *args: None):
        return native.validate_receipt(path, {native.SCOPE}, runtime=False, prepared=False)


def test_authorization_neutral_fixture_only(authorization):
    path, value, _ = authorization
    assert check(path)["session_id"] == SESSION
    # It cannot be used as a runtime source admission: its neutral source is not a ZIP.
    with patch.object(native, "verify_reception", lambda *args: None), patch.object(native, "verify_luna_release", lambda *args: None), pytest.raises(zipfile.BadZipFile):
        native.validate_receipt(path, {native.SCOPE}, prepared=False)
    # Without the explicit unit stub, prepared=False still refuses this fake receipt.
    with pytest.raises(InfrastructureError):
        native.validate_receipt(path, {native.SCOPE}, runtime=False, prepared=False)
    assert value["job_id"] == "999999"


@pytest.mark.parametrize(("field", "value"), [("model", "gpt-6-luna"), ("model", "gpt-6.1-sol"),
    ("model", "gpt-5.6-terra"), ("effort", "xhigh"), ("effort", "high"),
    ("session_id", "0" * 32), ("verified", False), ("scope_id", "hpc-forest-archives-2020-2024-mother-r1"),
    ("scope_id", "hpc-forest-primes-native-max-r2g"),
    ("native_calls_started_at_authorization", 1), ("operator_algorithm_advice", True),
    ("expires_at", 0)])
def test_authorization_refuses_other_identity_or_unverified(authorization, field, value):
    path, data, _ = authorization
    data[field] = value
    atomic_json(path, data)
    with pytest.raises(InfrastructureError):
        check(path)


@pytest.mark.parametrize("key", sorted(native.SCHEMAS))
def test_each_future_proof_must_be_verified(authorization, key):
    path, data, save = authorization
    proof = native.read_json(Path(data["artifacts"][key]["path"]))
    proof["verified"] = False
    data["artifacts"][key] = save(key + "-negative.json", proof)
    atomic_json(path, data)
    with pytest.raises(InfrastructureError):
        check(path)


def test_qualification_other_flags_rejected(authorization):
    path, data, save = authorization
    proof = native.read_json(Path(data["artifacts"]["allocated_contract_qualification"]["path"]))
    proof["compiler_flags"] = ["-O2", "-std=c11", "-lm"]
    data["artifacts"]["allocated_contract_qualification"] = save("wrong-flags.json", proof)
    atomic_json(path, data)
    with pytest.raises(InfrastructureError):
        check(path)


def test_fifth_worker_rejected(authorization):
    path, data, save = authorization
    proof = native.read_json(Path(data["artifacts"]["worker_lane_admission"]["path"]))
    proof["active_native_workers_before_start"] = 4
    data["artifacts"]["worker_lane_admission"] = save("too-many-workers.json", proof)
    atomic_json(path, data)
    with pytest.raises(InfrastructureError):
        check(path)


def test_changed_artifact_rejected(authorization):
    path, data, _ = authorization
    Path(data["artifacts"]["source_zip"]["path"]).write_bytes(b"CHANGED")
    with pytest.raises(InfrastructureError):
        check(path)


def test_allocation_refuses_windows_before_subprocess(monkeypatch):
    monkeypatch.setattr(native.platform, "system", lambda: "Windows")
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: pytest.fail("No subprocess authorized"))
    with pytest.raises(InfrastructureError):
        native.allocation_guard()


def test_deadline_exclusive_refused():
    with pytest.raises(InfrastructureError):
        native.deadline_guard(native.DEADLINE - native.MAX_ALLOCATION_SECONDS - native.RECEIPT_RESERVE_SECONDS)


def test_certified_files_and_split(sealed):
    data = verify_preparation(sealed)
    spec = specification(data)
    assert len(spec["search_cases"]) == len(spec["confirmation_cases"]) == 6
    assert all("v0" in case["stdin"]["file"] for case in spec["search_cases"])
    assert all("v1" in case["stdin"]["file"] for case in spec["confirmation_cases"])
    assert spec["benchmark_case"]["stdin"] == {"file": "private-audit-fixtures/p30-v0/input.txt"}
    assert spec["comparison"] == {"mode": "bytes"}
    assert spec["compiler_flags"] == COMPILER_FLAGS
    assert all("python" not in case["stdin"] and "text" not in case["stdin"]
               for case in [*spec["search_cases"], *spec["confirmation_cases"]])


def test_contract_generic_one_to_eight_bounds(sealed):
    data = verify_preparation(sealed)
    spec = specification(data)
    spec["search_cases"] *= 2
    with pytest.raises(contracts.ContractError, match="case_count"):
        contracts.validate_contract(spec, data)


def test_unmanifested_preparation_member_refused(sealed, tmp_path):
    copied = tmp_path / "sealed"
    shutil.copytree(sealed, copied)
    (copied / "data/extra.c").write_text("UNMANIFESTED")
    with pytest.raises(InfrastructureError):
        verify_preparation(copied)


def test_materialize_copies_exact_bytes_without_subprocess(sealed, tmp_path, monkeypatch):
    data = verify_preparation(sealed)
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: pytest.fail("No subprocess authorized"))
    resources = tmp_path / "validation"
    case = specification(data)["search_cases"][0]
    actual = contracts.materialize(case, data, resources / "case", resources)
    assert (resources / actual["stdin"]).read_bytes() == (data / case["stdin"]["file"]).read_bytes()


def test_expected_bytes_mismatch_refused(sealed, tmp_path):
    data = verify_preparation(sealed)
    mapping = expected_mapping()
    rows = []
    for name, origin in mapping.items():
        path = tmp_path / (name + ".stdin")
        path.write_bytes((data / "private-audit-fixtures" / origin / "input.txt").read_bytes())
        rows.append({"name": name, "stdin": path.name, "argv": [], "files": [], "capture_files": [],
                     "expected": {"stdout": contracts.blob((data / "private-audit-fixtures" / origin / "expected.txt").read_bytes())}})
    value = {"language": "c", "source_files": ["model-view/primetest.c"], "comparison": {"mode": "bytes"}, "compiler_flags": COMPILER_FLAGS,
             "search": rows[:6], "confirmation": rows[6:12], "benchmark": rows[12]}
    atomic_json(tmp_path / "contract.json", value)
    assert len(verify_resolved_expected(tmp_path, data)) == 13
    value["confirmation"][0]["expected"]["stdout"] = contracts.blob(b"WRONG\n")
    atomic_json(tmp_path / "contract.json", value)
    with pytest.raises(InfrastructureError):
        verify_resolved_expected(tmp_path, data)


@pytest.mark.parametrize("timedout", [False, True])
def test_candidate_stderr_private_and_audited(tmp_path, monkeypatch, timedout):
    secret = b"PRIVATE_INPUT_MARKER_927381\n"
    resources = tmp_path / "validation"
    resources.mkdir()
    (resources / "stdin.data").write_bytes(secret)
    case = {"name": "search-case-1", "stdin": "stdin.data", "argv": [], "files": [],
            "capture_files": [], "stdin_bytes": len(secret), "input_fingerprint": "PRIVATE_HASH"}
    def fake_run(*args, **kwargs):
        assert kwargs["stdin"].read() == secret
        kwargs["stderr"].write(secret)
        kwargs["stdout"].write(secret)
        if timedout:
            raise subprocess.TimeoutExpired("NEUTRAL", 1, stderr=secret)
        return SimpleNamespace(returncode=7)
    monkeypatch.setattr(contracts.subprocess, "run", fake_run)
    (tmp_path / "not-a-real-binary").write_bytes(b"INERT_NEVER_EXECUTED")
    with pytest.raises(contracts.ContractError) as exc:
        contracts.execute(tmp_path / "not-a-real-binary", case, resources=resources)
    assert "PRIVATE" not in str(exc.value)
    assert "stderr" not in exc.value.diagnostic
    audits = list((tmp_path / "private-audit/executions").iterdir())
    assert len(audits) == 1
    assert (audits[0] / "stderr.bin").read_bytes() == secret
    assert (audits[0] / "stdout.bin").read_bytes() == secret


def test_compiler_stderr_is_not_exception_feedback(tmp_path, monkeypatch):
    secret = b"PRIVATE_COMPILER_MARKER_7391"
    monkeypatch.setattr(contracts.shutil, "which", lambda name: "NEUTRAL_COMPILER")
    monkeypatch.setattr(contracts.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=1, stdout=secret, stderr=secret))
    with pytest.raises(contracts.ContractError) as exc:
        contracts.build_source(tmp_path, tmp_path / "build", {"language": "c", "source_files": ["never.c"], "compiler_flags": COMPILER_FLAGS})
    assert "PRIVATE" not in str(exc.value)
    assert (tmp_path / "build/compiler.stderr").read_bytes() == secret
    assert native.read_json(tmp_path / "build/compiler-command.json")["compiler_flags"] == COMPILER_FLAGS


@pytest.mark.parametrize("raw", [b"PRIVATE_RAW_LEAK", b'{"stderr":"PRIVATE_JSON_LEAK","input":"PRIVATE","code":"execution_failed","field":"search-case-1"}', b'{"diagnostic":{"code":"PRIVATE_CODE","field":"PRIVATE_CASE","message":"PRIVATE_MESSAGE"}}'])
def test_raw_logs_never_enter_any_projection(tmp_path, raw):
    path = tmp_path / "raw.log"
    path.write_bytes(raw)
    outcome = {"status": "incorrect", "logs": [str(path)], "reason": "PRIVATE_REASON", "stderr": "PRIVATE"}
    for projected in (diagnostic_logs(tmp_path, outcome), _logs(tmp_path, outcome), public_outcome(outcome)):
        assert "PRIVATE" not in json.dumps(projected)
    assert path.read_bytes() == raw


def test_diagnostic_closed_keys():
    value = public_diagnostic({"diagnostic": {"code": "execution_failed", "field": "search-case-1", "returncode": 2,
                                             "stderr": "PRIVATE", "message": "PRIVATE", "expected": "PRIVATE"}})
    assert value == {"status": "failed", "code": "execution_failed", "case": "search-case-1", "returncode": 2}


def test_harness_next_model_context_never_sees_private_diagnostics(tmp_path, monkeypatch):
    from hpc_forest import node_harness as harness
    from hpc_forest.backends import Generated
    worktree = tmp_path / "worktree"
    (worktree / "src").mkdir(parents=True)
    (worktree / "src/neutral.txt").write_text("NEUTRAL SOURCE DATA, NEVER EXECUTED")
    (tmp_path / "trusted").mkdir()
    log = tmp_path / "private.log"
    atomic_json(log, {"diagnostic": {"code": "execution_failed", "field": "search-case-1", "stderr": "PRIVATE_LEAK"}})
    seen = []
    class Backend:
        def generate(self, mission, context, config, root):
            seen.append(context)
            assert "PRIVATE_LEAK" not in json.dumps(context)
            return Generated(tokens=1, usage={"llm_calls": 1})
    class Evaluator:
        def __init__(self, *args):
            pass
        def precheck(self, *args):
            return Outcome("incorrect", correct=False, reason="PRIVATE_REASON", logs=[str(log)])
    monkeypatch.setattr(harness, "Evaluator", Evaluator)
    monkeypatch.setattr(harness, "assert_allowed_changes", lambda *a: None)
    monkeypatch.setattr(harness, "git", lambda *a: "neutral-commit")
    monkeypatch.setattr(harness, "initialize_source", lambda *a: "neutral-commit")
    mission = Mission("neutral-exp", "tree", "trial", 1, "A", "neutral-commit", None, "root", 1, 1, str(worktree))
    config = {"harness": {"enabled": True, "max_attempts": 2, "call_token_ceiling": 10,
                           "research": {"enabled": False}},
              "budget": {"mission_tokens": 20, "generation_seconds": 60, "confirmation_seconds": 0}}
    result = harness.NodeHarness(Backend()).generate(mission, {"deadline": time.time() + 60, "protocol_id": "neutral"}, config, tmp_path)
    assert result.usage["harness_attempts"] == 2 and len(seen) == 2
    assert "PRIVATE" not in json.dumps(seen[1]["automatic_observations"])
    assert "PRIVATE_LEAK" in log.read_text()


def load_script(name):
    path = Path(__file__).resolve().parents[1] / "examples/marathon22" / name
    spec = importlib.util.spec_from_file_location("r2_neutral_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_final_qualifier_refuses_before_creation_or_compile(tmp_path, monkeypatch):
    module = load_script("qualify_r2max_contract.py")
    monkeypatch.setattr(native.platform, "system", lambda: "Windows")
    monkeypatch.setattr(contracts.subprocess, "run", lambda *a, **k: pytest.fail("No compiler/candidate authorized"))
    with pytest.raises(InfrastructureError):
        module.qualify(tmp_path, tmp_path / "must-not-exist", tmp_path / "missing", tmp_path / "missing-plan")
    assert not (tmp_path / "must-not-exist").exists()


def test_native_runner_has_one_cell_and_no_legacy_preparer():
    module = load_script("primes_native_max.py")
    text = Path(module.__file__).read_text()
    assert "gpt-6-astra" not in text and "gpt-6.1-sol" not in text and "gpt-5.6-terra" not in text
    assert "archive_preparation" not in text and "text_input" not in text
    assert "first_start_receipt" in text and '"automatic_extension": False' in text
    assert "subprocess" not in text


def test_missing_first_start_cannot_be_verified(tmp_path, authorization):
    _, data, _ = authorization
    channel = tmp_path / "mailbox"
    (channel / "requests").mkdir(parents=True)
    controller = SimpleNamespace(db=SimpleNamespace(rows=lambda *a: []))
    result = first_start_receipt(controller, channel, data, {"job_id": "999999"}, tmp_path / "first.json")
    assert result["verified"] is False and result["blocking_reasons"]
    assert result["extension_to_other_models_allowed"] is False


def make_normal_call(tmp_path, authorization, *, unknown=False):
    _, auth, _ = authorization
    channel = tmp_path / "neutral-channel"
    for name in ("requests", "responses", "logs"):
        (channel / name).mkdir(parents=True)
    nonce = "a" * 32
    request = {"nonce": nonce, "kind": "source-proposal", "mission_id": "neutral-exp-h01",
               "model": MODEL, "reasoning_effort": "max", "session_id": SESSION}
    request_path = channel / "requests" / f"{nonce}.request.json"
    atomic_json(request_path, request)
    request_sha = file_digest(request_path)
    log_path = channel / "logs" / f"{nonce}.codex.jsonl"
    log_path.write_text("NEUTRAL EVENT DATA; NO MODEL OR CLI EXECUTED")
    response = {**request, "request_sha256": request_sha, "error": None, "infrastructure_error": False,
                "usage": {"tokens": 1, "llm_calls": 1, "tool_events": [],
                          "token_accounting": "upper_bound" if unknown else "exact",
                          "codex_jsonl_sha256": file_digest(log_path)}}
    response_path = channel / "responses" / f"{nonce}.response.json"
    atomic_json(response_path, response)
    atomic_json(channel / "responses" / f"{nonce}.ready.json", {"sha256": file_digest(response_path), "bytes": response_path.stat().st_size})
    cli = native.read_json(Path(auth["artifacts"]["cli_identity"]["path"]))
    atomic_json(channel / "worker-ready.json", {**native.cell_binding(auth), "owner": auth["job_id"], "mode": "codex",
                "model": MODEL, "reasoning_effort": "max", "session_id": SESSION,
                "source_zip_sha256": auth["artifacts"]["source_zip"]["sha256"],
                "plan_sha256": auth["artifacts"]["plan"]["sha256"],
                "codex_executable": cli["executable_path"], "codex_cli_version": cli["version"],
                "codex_executable_sha256": cli["executable_sha256"]})
    policy_path = tmp_path / ("cli-policy-" + SESSION + ".json")
    policy = codex_process.load_task_cli_policy(policy_path, cli["task_cli_policy_sha256"],
                                               native.cell_binding(auth), cli["executable_sha256"])
    private_output = tmp_path / "NEUTRAL-private-cli" / nonce
    command_request = {**request, "schema": {"type": "object"},
        "messages": [{"role": "system", "content": "NEUTRAL COMMAND FIXTURE; NEVER EXECUTED"},
                     {"role": "user", "content": "NEUTRAL DATA"}]}
    with patch.object(codex_process, "MODEL", MODEL), patch.object(codex_process, "EFFORT", "max"), \
            patch.object(codex_process, "CLI_POLICY", policy), \
            patch.object(codex_process.shutil, "which", lambda _: cli["executable_path"]):
        argv = codex_process.command_for(command_request, private_output)
        private_invocation = private_output / "invocation.json"
        atomic_json(private_invocation, {"argv": argv, "model": MODEL,
                    "reasoning_effort": "max", "request_sha256": request_sha, "source_execution_allowed": False})
        private_process = private_output / "process.json"
        atomic_json(private_process, {"argv": argv, "returncode": 0, "timed_out": False})
        atomic_json(channel / "logs" / f"{nonce}.invocation.json",
                    codex_process.cli_metadata_projection(private_invocation, cli["task_cli_policy_sha256"], "invocation"))
        atomic_json(channel / "logs" / f"{nonce}.codex.jsonl.json",
                    codex_process.cli_metadata_projection(private_process, cli["task_cli_policy_sha256"], "process"))
    atomic_json(channel / "logs" / f"{nonce}.delivered.json", {"request_sha256": request_sha,
                "response_sha256": file_digest(response_path), "scope_id": native.SCOPE,
                "model": MODEL, "effort": "max", "session_id": SESSION, "job_id": auth["job_id"],
                "source_zip_sha256": auth["artifacts"]["source_zip"]["sha256"],
                "plan_sha256": auth["artifacts"]["plan"]["sha256"]})
    atomic_json(tmp_path / "runtime-reference-origin.json", {"schema": "hpc-forest-primes-r2max-runtime-reference-v1",
                "verified": True, "job_id": auth["job_id"], "reference_origin_is_current_allocation": True,
                "qualification_timings_imported": False, "source_zip_sha256": auth["artifacts"]["source_zip"]["sha256"],
                "plan_sha256": auth["artifacts"]["plan"]["sha256"], "native_model_calls": 0})
    return channel, request_path


@pytest.mark.parametrize("status", ["build_failed", "incorrect", "valid"])
def test_first_start_preserves_negative_and_requires_real_call_evaluation(tmp_path, authorization, status):
    _, data, _ = authorization
    channel, request = make_normal_call(tmp_path, authorization)
    assert inspect_call(channel, request, data)["normal_delivered"] is True
    log = tmp_path / "evaluation.log"
    log.write_text("NEUTRAL EVALUATION RECORD; NOT AN EXECUTED CANDIDATE")
    context = {"schema": "hpc-forest-private-evaluation-context-v1", "experiment_id": "neutral-exp",
               "phase": "search", "operation": "build", "argv": ["INERT_NOT_RUN"], "private_cases": [],
               "binary_sha256_before": None, "never_model_input": True}
    context_path = log.with_suffix(".private-context.json")
    atomic_json(context_path, context)
    atomic_json(log.with_suffix(".log.private-execution.json"), {
        **context, "context": {"path": str(context_path), "sha256": file_digest(context_path)},
        "schema": "hpc-forest-private-evaluation-execution-v2", "verified": True,
        "experiment_id": "neutral-exp", "phase": "search", "never_model_input": True,
        "streams": {"combined_stdout_stderr": {"sha256": file_digest(log), "bytes": log.stat().st_size},
                    "layout": "original_run_process_combined_unchanged", "separate_stdout": None, "separate_stderr": None},
        "hashing_outside_measured_interval": True, "execution_semantics_changed": False})
    rows = [{"id": "neutral-exp", "result": json.dumps({"status": status, "correct": status == "valid", "logs": [str(log)]})}]
    controller = SimpleNamespace(db=SimpleNamespace(rows=lambda *a: rows, path=tmp_path / "never-created.sqlite"))
    result = first_start_receipt(controller, channel, data, {"job_id": data["job_id"]}, tmp_path / "first.json")
    assert result["verified"] is True
    assert result["first_real_evaluation"]["candidate_negative_preserved"] is (status != "valid")
    assert result["extension_to_other_models_allowed"] is False


def test_unknown_native_call_blocks_first_start(tmp_path, authorization):
    _, data, _ = authorization
    channel, request = make_normal_call(tmp_path, authorization, unknown=True)
    with pytest.raises(ValueError, match="Unknown"):
        inspect_call(channel, request, data)


def test_runtime_must_equal_admitted_zip(tmp_path, monkeypatch):
    root = tmp_path / "runtime"
    code = root / "src/hpc_forest/native_r2max.py"
    code.parent.mkdir(parents=True)
    code.write_text("NEUTRAL SOURCE, NEVER IMPORTED")
    zpath = tmp_path / "neutral.zip"
    with zipfile.ZipFile(zpath, "w") as archive:
        archive.writestr("HPC-Forest/src/hpc_forest/native_r2max.py", code.read_bytes())
    monkeypatch.setattr(native, "__file__", str(code))
    native.verify_runtime(zpath)
    code.write_text("CHANGED")
    with pytest.raises(InfrastructureError):
        native.verify_runtime(zpath)


def test_standalone_checker_main_never_reemits_candidate_stderr(tmp_path, monkeypatch, capsys):
    import runpy
    import sys
    resources = tmp_path / "validation"
    resources.mkdir()
    tool = resources / "contract_tool.py"
    tool.write_bytes(Path(contracts.__file__).read_bytes())
    (resources / "stdin.data").write_bytes(b"PRIVATE_STDIN_MAIN")
    case = {"name": "search-case-1", "stdin": "stdin.data", "argv": [], "files": [],
            "capture_files": [], "stdin_bytes": 18, "input_fingerprint": "PRIVATE", "expected": {"stdout": contracts.blob(b"EXPECTED")}}
    atomic_json(resources / "contract.json", {"search": [case], "benchmark": case, "case_timeout_seconds": 1, "comparison": {"mode": "bytes"}})
    def fake_run(*args, **kwargs):
        kwargs["stderr"].write(b"PRIVATE_STDERR_MAIN")
        kwargs["stdout"].write(b"PRIVATE_STDOUT_MAIN")
        return SimpleNamespace(returncode=9)
    monkeypatch.setattr(subprocess, "run", fake_run)
    (tmp_path / "never-executed").write_bytes(b"INERT_NEVER_EXECUTED")
    monkeypatch.setattr(sys, "argv", [str(tool), "check", str(tmp_path / "never-executed"), "search"])
    with pytest.raises(SystemExit) as exc:
        runpy.run_path(str(tool), run_name="__main__")
    assert exc.value.code == 1
    captured = capsys.readouterr()
    assert "PRIVATE" not in captured.out + captured.err
    assert json.loads(captured.err)["diagnostic"] == {"code": "execution_failed", "case": "search-case-1", "returncode": 9}
    assert next((tmp_path / "private-audit/executions").glob("*/stderr.bin")).read_bytes() == b"PRIVATE_STDERR_MAIN"


def test_transport_smoke_identity_never_verifies_first_start(tmp_path, authorization):
    _, auth, _ = authorization
    channel, _ = make_normal_call(tmp_path, authorization)
    ready = native.read_json(channel / "worker-ready.json")
    ready["mode"] = "transport-smoke"
    atomic_json(channel / "worker-ready.json", ready)
    controller = SimpleNamespace(db=SimpleNamespace(rows=lambda *a: []))
    result = first_start_receipt(controller, channel, auth, {"job_id": auth["job_id"]}, tmp_path / "smoke-negative.json")
    assert result["verified"] is False
    assert "normal native worker" in result["blocking_reasons"][0]


def test_unknown_authorization_fields_rejected(authorization):
    path, auth, _ = authorization
    auth["automatic_extension_override"] = True
    atomic_json(path, auth)
    with pytest.raises(InfrastructureError, match="unknown fields"):
        check(path)


def test_unknown_proof_fields_rejected(authorization):
    path, auth, save = authorization
    proof = native.read_json(Path(auth["artifacts"]["integration_review"]["path"]))
    proof["override_other_models"] = True
    auth["artifacts"]["integration_review"] = save("unknown-key.json", proof)
    atomic_json(path, auth)
    with pytest.raises(InfrastructureError, match="Unknown fields"):
        check(path)


def test_current_allocation_reference_is_prepared_fresh(tmp_path, monkeypatch):
    from hpc_forest import primes_contract as module
    calls = []
    def neutral_prepare(package, output):
        calls.append((package, output))
        return {"source": str(output / "source"), "validation": str(output / "validation"),
                "reference_timings": [{"name": "NEUTRAL", "seconds": [1, 2]}], "native_model_calls": 0}
    monkeypatch.setattr(module, "prepare_certified", neutral_prepare)
    receipt = module.prepare_runtime_reference(tmp_path / "package", tmp_path / "new-native", {"job_id": "NEW_JOB"},
                                               "1" * 64, "2" * 64, {"path": "/OLD_QUALIFICATION", "sha256": "3" * 64})
    assert calls == [(tmp_path / "package", tmp_path / "new-native/prepared")]
    origin = native.read_json(tmp_path / "new-native/runtime-reference-origin.json")
    assert origin["job_id"] == "NEW_JOB" and origin["reference_origin_is_current_allocation"] is True
    assert origin["qualification_timings_imported"] is False and origin["native_model_calls"] == 0
    assert receipt["reference_timings"] == [{"name": "NEUTRAL", "seconds": [1, 2]}]


def test_first_start_refuses_reference_from_another_allocation(tmp_path, authorization):
    _, auth, _ = authorization
    channel, _ = make_normal_call(tmp_path, authorization)
    path = tmp_path / "runtime-reference-origin.json"
    origin = native.read_json(path)
    origin["job_id"] = "OLD_JOB"
    atomic_json(path, origin)
    controller = SimpleNamespace(db=SimpleNamespace(rows=lambda *a: []))
    result = first_start_receipt(controller, channel, auth, {"job_id": auth["job_id"]}, tmp_path / "old-timings-negative.json")
    assert result["verified"] is False and "current native allocation" in result["blocking_reasons"][0]


@pytest.mark.parametrize("cores,accepted", [(4, True), (5, False), (3, False)])
def test_allocation_requires_exact_four_affine_cpus(monkeypatch, cores, accepted):
    monkeypatch.setattr(native.platform, "system", lambda: "Linux")
    monkeypatch.setattr(native.platform, "machine", lambda: "aarch64")
    monkeypatch.setattr(os, "sched_getaffinity", lambda pid: set(range(cores)), raising=False)
    for key, value in {"SLURM_JOB_ID": "999999", "SLURM_JOB_NUM_NODES": "1", "SLURM_NTASKS": "1",
                       "SLURM_CPUS_PER_TASK": "4", "SLURM_MEM_PER_NODE": "16384"}.items():
        monkeypatch.setenv(key, value)
    for key in ("SLURM_GPUS", "SLURM_GPUS_PER_NODE", "SLURM_JOB_GPUS", "SLURM_STEP_GPUS", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(key, raising=False)
    if accepted:
        assert native.allocation_guard()["cpus_per_task"] == 4
    else:
        with pytest.raises(InfrastructureError):
            native.allocation_guard()


def test_post_submit_wait_is_bounded_and_starts_no_native_work(tmp_path, monkeypatch):
    module = load_script("wait_r2max_authorization.py")
    ticks = iter([0, 2])
    monkeypatch.setattr(module.time, "monotonic", lambda: next(ticks))
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: pytest.fail("No command allowed during wait"))
    with pytest.raises(InfrastructureError, match="did not arrive"):
        module.await_authorization(tmp_path / "missing.json", tmp_path / "missing-ready.json", 1, {"job_id": "999999"})
    assert list(tmp_path.iterdir()) == []


def test_post_submit_wrong_job_ready_rejected_before_authorization(tmp_path):
    module = load_script("wait_r2max_authorization.py")
    path = tmp_path / "auth.json"
    path.write_text("NOT AN AUTHORIZATION")
    ready = tmp_path / "ready.json"
    atomic_json(ready, {"schema": "hpc-forest-primes-r2max-authorization-upload-ready-v1", "scope_id": native.SCOPE,
                       "session_id": SESSION, "job_id": "WRONG", "sha256": file_digest(path), "bytes": path.stat().st_size})
    with pytest.raises(InfrastructureError, match="unrelated"):
        module.await_authorization(path, ready, 1, {"job_id": "999999"})


@pytest.mark.parametrize("phase", ["search", "confirmation"])
def test_duplicate_phase_names_cannot_replace_six_certified_cases(sealed, tmp_path, phase):
    from hpc_forest.primes_contract import verify_resolved_values
    data = verify_preparation(sealed)
    rows = {name: {"name": name, "argv": [], "files": [], "capture_files": [], "stdin": name,
                   "expected": {"stdout": contracts.blob((data / "private-audit-fixtures" / origin / "expected.txt").read_bytes())}}
            for name, origin in expected_mapping().items()}
    resolved = {"language": "c", "source_files": ["model-view/primetest.c"], "comparison": {"mode": "bytes"},
                "compiler_flags": COMPILER_FLAGS, "search": [rows[f"search-case-{n}"] for n in range(1, 7)],
                "confirmation": [rows[f"confirmation-case-{n}"] for n in range(1, 7)], "benchmark": rows["benchmark-case-1"]}
    resolved[phase] = [resolved[phase][0]] * 6
    with pytest.raises(InfrastructureError, match="six unique"):
        verify_resolved_values(resolved, data, lambda name: pytest.fail("Duplicates must fail before reading any input"))


def test_self_declared_qualification_lacks_actual_command_source_contract(sealed):
    data = verify_preparation(sealed)
    proof = {"prepared_files": {"arbitrary.bin": "0" * 64}, "verified": True}
    with pytest.raises(InfrastructureError, match="actual build/source/contract"):
        native.verify_qualification_members(proof, lambda name: b"NEUTRAL", data)


def test_actual_reception_is_required_even_when_prepared_false(authorization):
    path, _, _ = authorization
    with pytest.raises(InfrastructureError):
        native.validate_receipt(path, {native.SCOPE}, runtime=False, prepared=False)


@pytest.mark.parametrize("status", ["duplicate", "generation_failed", "contract_violation"])
def test_known_model_negative_waits_for_real_evaluation_without_infrastructure_label(tmp_path, authorization, status):
    _, auth, _ = authorization
    channel, _ = make_normal_call(tmp_path, authorization)
    rows = [{"id": "neutral-exp", "result": json.dumps({"status": status, "correct": False, "logs": []})}]
    controller = SimpleNamespace(db=SimpleNamespace(rows=lambda *a: rows))
    result = first_start_receipt(controller, channel, auth, {"job_id": auth["job_id"]}, tmp_path / "known-negative.json")
    assert result["verified"] is False and result["pending_first_real_evaluation"] is True
    assert result["technical_errors_found"] is False and result["invocation_unknown"] is False
    assert result["extension_to_other_models_allowed"] is False


def test_model_response_error_with_exact_known_usage_is_a_known_negative(tmp_path, authorization):
    _, auth, _ = authorization
    channel, request = make_normal_call(tmp_path, authorization)
    response_path = next((channel / "responses").glob("*.response.json"))
    response = native.read_json(response_path)
    response["error"] = "Neutral malformed model object; process completed normally"
    atomic_json(response_path, response)
    ready_path = next((channel / "responses").glob("*.ready.json"))
    atomic_json(ready_path, {"sha256": file_digest(response_path), "bytes": response_path.stat().st_size})
    delivery_path = next((channel / "logs").glob("*.delivered.json"))
    delivered = native.read_json(delivery_path)
    delivered["response_sha256"] = file_digest(response_path)
    atomic_json(delivery_path, delivered)
    call = inspect_call(channel, request, auth)
    assert call["known_model_negative"] is True and call["normal_delivered"] is True


def test_every_batch_stops_immediately_on_new_unknown_invocation(tmp_path, monkeypatch):
    module = load_script("primes_native_max.py")
    sequence = iter([{"verified": True, "technical_errors_found": False},
                     {"verified": False, "technical_errors_found": True}])
    paths = []
    def neutral_receipt(*args):
        paths.append(args[-1])
        return next(sequence)
    monkeypatch.setattr(module, "first_start_receipt", neutral_receipt)
    first_verified, _ = module.reconcile_after_batch(None, None, {}, {}, tmp_path, False)
    assert first_verified is True
    with pytest.raises(InfrastructureError, match="stop immediately"):
        module.reconcile_after_batch(None, None, {}, {}, tmp_path, first_verified)
    assert [path.name for path in paths] == ["premier-demarrage-verifie.json", "reconciliation-en-cours.json"]


@pytest.mark.parametrize("before", [0, 1, 2, 3])
def test_r2c_cap4_accepts_each_available_native_lane(before):
    assert native.MAXIMUM_NATIVE_WORKERS == 4
    native.verify_worker_lane({"active_native_workers_before_start": before, "maximum_native_workers": 4})


@pytest.mark.parametrize(("before", "maximum"), [(4, 4), (5, 4), (-1, 4), (True, 4), (1.0, 4), (None, 4), (1, 2), (1, 5)])
def test_r2c_cap4_refuses_fifth_bad_count_and_other_caps(before, maximum):
    with pytest.raises(InfrastructureError):
        native.verify_worker_lane({"active_native_workers_before_start": before, "maximum_native_workers": maximum})


@pytest.mark.parametrize("model", sorted(native.CELLS))
def test_r2h_all_four_fresh_max_identities_are_individually_selectable(model):
    assert native.SCOPE == "hpc-forest-primes-native-max-r2h"
    assert native.CELLS == {"gpt-6-luna": "d231e8f9f0ee433b8f05aa8aa3fae22f",
                            "gpt-6-astra": "798b99a175d4454d9371e8ba898503e4",
                            "gpt-5.6-terra": "7a46678417dc450c93fd23f76132e90f",
                            "gpt-6.1-sol": "0f1de21e9eda4fb89a8dbd66c6fa8d6c"}
    assert native.selected_identity({"model": model, "effort": "max", "session_id": native.CELLS[model]}) == (model, native.CELLS[model])


def test_r2h_refuses_historical_luna_session():
    assert native.CELLS["gpt-6-luna"] != native.LUNA_SESSION
    with pytest.raises(InfrastructureError):
        native.selected_identity({"model": "gpt-6-luna", "effort": "max", "session_id": native.LUNA_SESSION})


@pytest.mark.parametrize(("effort", "session"), [("xhigh", SESSION), ("medium", SESSION), ("max", "0" * 32)])
def test_r2c_still_refuses_other_effort_or_session(effort, session):
    with pytest.raises(InfrastructureError):
        native.selected_identity({"model": MODEL, "effort": effort, "session_id": session})


@pytest.mark.parametrize("before", [0, 1, 2, 3])
def test_r2c_full_metadata_guard_accepts_cap4_lane_only_in_neutral_fixture(authorization, before):
    path, data, save = authorization
    proof = native.read_json(Path(data["artifacts"]["worker_lane_admission"]["path"]))
    proof["active_native_workers_before_start"] = before
    proof["lane_v2"]["active_native_workers_before_start"] = before
    projection = native.read_json(Path(proof["lane_v2"]["minimal_owned_observations"]["path"]))
    projection.update(active_native_workers_before_start=before, other_native_workers_count=before)
    proof["lane_v2"]["minimal_owned_observations"] = save("NEUTRAL-cap4-projection.json", projection)
    data["artifacts"]["worker_lane_admission"] = save("NEUTRAL-cap4-lane.json", proof)
    atomic_json(path, data)
    assert check(path)["job_id"] == "999999"
    # The deliberately non-ZIP metadata fixture never becomes a real runtime admission.
    with pytest.raises(InfrastructureError):
        native.validate_receipt(path, {native.SCOPE}, runtime=False, prepared=False)


@pytest.mark.parametrize("key", ["worker_lane_admission", "extension_admission"])
def test_r2c_full_metadata_guard_refuses_old_cap2(authorization, key):
    path, data, save = authorization
    proof = native.read_json(Path(data["artifacts"][key]["path"]))
    proof["maximum_native_workers"] = 2
    data["artifacts"][key] = save("NEUTRAL-old-cap.json", proof)
    atomic_json(path, data)
    with pytest.raises(InfrastructureError):
        check(path)


@pytest.mark.parametrize(("field", "value"), [("maximum_native_workers_total", 2), ("maximum_cells_per_authorization", 2)])
def test_r2c_plan_cap_and_single_cell_cannot_be_bypassed(authorization, field, value):
    path, data, save = authorization
    plan = native.read_json(Path(data["artifacts"]["plan"]["path"]))
    plan[field] = value
    data["artifacts"]["plan"] = save("NEUTRAL-wrong-plan.json", plan)
    atomic_json(path, data)
    with pytest.raises(InfrastructureError):
        check(path)


def test_r2c_cap4_does_not_allow_rebinding_a_started_cache(tmp_path):
    authorization = {"model": MODEL, "effort": "max", "session_id": SESSION, "job_id": "999999",
        "remote_root": "/NEUTRAL/" + native.SCOPE + "-" + SESSION,
        "artifacts": {"source_zip": {"sha256": "NEUTRAL_NOT_DEPLOYABLE"}, "plan": {"sha256": "NEUTRAL_NOT_DEPLOYABLE"}}}
    cache = tmp_path / "NEUTRAL-cache"
    native.bind_worker_cache(cache, authorization)
    other = {**authorization, "job_id": "999997"}
    with pytest.raises(InfrastructureError):
        native.bind_worker_cache(cache, other)
